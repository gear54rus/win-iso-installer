To update the driver pack, modify DPMS.ISO and replace "D" and all subfolders with the new ones. 
Then rename to DriverPack_MassStorage_wnt5_x86-32.ini to DriverPack.ini and replace the existing one.
To obtain the latest BTS mass storage driver pack visit:
http://www.driverpacks.net/driverpacks/windows/xp/x86/mass-storage/

If planning to use DPMS out of WinSetupFromUSB you may want to download devcon.exe, EXTRACT FIRST and put devcon.exe only in FIRA directory.
http://download.microsoft.com/download/1/1/f/11f7dd10-272d-4cd2-896f-9ce67f3e0240/devcon.exe