Thanks to marv:
http://www.911cd.net/forums//index.php?showtopic=22473

And of course Dietmar who made all that possible:
http://www.911cd.net/forums//index.php?showtopic=14181
